/**
 * 获取数据模块
 * 优先 fetch 读取本地 JSON；沙盒/file:// 下 fetch 不可用就立刻用内置 data.js
 * 绝不卡住等待——参考 ai-python-32 的 fetchWorks() 探测方案
 */
async function fetchWorks() {
    try {
        // 探测一个小文件，500ms 内没响应就认为 fetch 不可用
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 500);
        const r = await fetch('./data/textbook.json', { signal: controller.signal, method: 'HEAD' });
        clearTimeout(timer);
        return !!(r && r.ok);
    } catch (e) { return false; }
}

async function getTextbookData() {
    // file:// 协议直接用内置数据
    if (window.location.protocol === 'file:') {
        console.log("📂 file:// 模式，使用内置 data.js");
        return textbookData;
    }

    // 先探测 fetch 是否可用（沙盒 iframe 里 fetch 会被当成跨域拦掉）
    if (!(await fetchWorks())) {
        console.log("⚠️ 沙盒/file:// 环境，fetch 不可用，直接使用内置 data.js");
        return textbookData;
    }

    try {
        const response = await fetch('./data/textbook.json');
        if (!response.ok) throw new Error("HTTP Error");
        const data = await response.json();
        console.log("✅ fetch 加载数据成功");
        return data;
    } catch (error) {
        console.warn("⚠️ fetch 失败，降级到内置 data.js");
        return textbookData;
    }
}