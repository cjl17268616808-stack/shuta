const takuEngine = {
    dialogElement: document.getElementById('taku-text'),
    dialogBox: document.getElementById('taku-dialog'),
    muteBtn: document.getElementById('mute-btn'),
    settingsPanel: document.getElementById('settings-panel'),
    bgmAudio: document.getElementById('bgm-audio'),
    timer: null,
    isMuted: false,
    isAudioUnlocked: false,
    ttsSupported: true, // 标记设备是否支持TTS

    voiceRate: 1.0,
    voicePitch: 1.1,
    selectedVoice: null,
    voiceList: [],

    isDragging: false,
    hasDragged: false,
    startX: 0, startY: 0, startLeft: 0, startTop: 0,

    init() {
        if (!('speechSynthesis' in window)) {
            console.warn("⚠️ 当前浏览器不支持语音合成，塔库将使用纯文字模式。");
            this.ttsSupported = false;
            if (this.muteBtn) this.muteBtn.style.display = 'none';
            this.isMuted = true;
        } else {
            this.loadVoices();
            if (window.speechSynthesis.onvoiceschanged !== undefined) {
                window.speechSynthesis.onvoiceschanged = () => this.loadVoices();
            }
        }

        this.initDrag();

        // 第一次交互：解锁音频。浏览器规定"必须先有用户操作才能出声"，
        // 背景音乐（bgmEngine）就等这一下，然后自动开始放默认曲目。
        document.addEventListener('click', () => {
            if (!this.isAudioUnlocked) {
                this.isAudioUnlocked = true;
                if (this.ttsSupported) window.speechSynthesis.resume();
                if (window.bgmEngine) bgmEngine.unlock();
            }
        }, { once: true });

        const rateSlider = document.getElementById('voice-rate');
        const pitchSlider = document.getElementById('voice-pitch');

        if(rateSlider) rateSlider.oninput = () => { document.getElementById('rate-value').innerText = rateSlider.value; this.applyVoiceSettings(); };
        if(pitchSlider) pitchSlider.oninput = () => { document.getElementById('pitch-value').innerText = pitchSlider.value; this.applyVoiceSettings(); };
        // 音乐音量条由 bgmEngine 自己接管（见 index.html 的 oninput），这里不再重复绑定

        // fallback：3秒后如果还卡在"系统启动中"，显示默认欢迎语
        setTimeout(() => {
            const t = document.getElementById('taku-text');
            if (t && (t.innerText === '系统启动中...' || t.innerText.trim() === '')) {
                t.innerText = '哔哔——数据流连接成功！我是塔库，点下面的塔开始攀登吧！';
            }
        }, 3000);
    },

    // 拖拽核心逻辑（保持不变）
    initDrag() {
        const takuArea = document.getElementById('taku-area');
        if (!takuArea) return;
        const savedLeft = localStorage.getItem('takuLeft');
        const savedTop = localStorage.getItem('takuTop');
        if (savedLeft && savedTop) {
            takuArea.style.bottom = 'auto';
            takuArea.style.left = savedLeft;
            takuArea.style.top = savedTop;
        }
        const onStart = (e) => {
            if (e.target.closest('.taku-dialog-box') && e.target.tagName !== 'P') return;
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            const rect = takuArea.getBoundingClientRect();
            takuArea.style.bottom = 'auto'; takuArea.style.right = 'auto';
            takuArea.style.left = rect.left + 'px'; takuArea.style.top = rect.top + 'px';
            this.startX = clientX; this.startY = clientY; this.startLeft = rect.left; this.startTop = rect.top;
            this.isDragging = true; this.hasDragged = false;
            document.addEventListener('mousemove', onMove); document.addEventListener('mouseup', onEnd);
            document.addEventListener('touchmove', onMove, { passive: false }); document.addEventListener('touchend', onEnd);
            takuArea.classList.add('dragging'); e.preventDefault();
        };
        const onMove = (e) => {
            if (!this.isDragging) return;
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            const dx = clientX - this.startX; const dy = clientY - this.startY;
            if (Math.abs(dx) > 5 || Math.abs(dy) > 5) this.hasDragged = true;
            let newLeft = this.startLeft + dx; let newTop = this.startTop + dy;
            newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - takuArea.offsetWidth));
            newTop = Math.max(0, Math.min(newTop, window.innerHeight - takuArea.offsetHeight));
            takuArea.style.left = newLeft + 'px'; takuArea.style.top = newTop + 'px';
            if (e.cancelable) e.preventDefault();
        };
        const onEnd = () => {
            if (!this.isDragging) return;
            this.isDragging = false; takuArea.classList.remove('dragging');
            document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onEnd);
            document.removeEventListener('touchmove', onMove); document.removeEventListener('touchend', onEnd);
            if (this.hasDragged) {
                localStorage.setItem('takuLeft', takuArea.style.left);
                localStorage.setItem('takuTop', takuArea.style.top);
            }
        };
        takuArea.addEventListener('mousedown', onStart);
        takuArea.addEventListener('touchstart', onStart, { passive: false });
        takuArea.addEventListener('click', (e) => { if (this.hasDragged) { e.stopPropagation(); e.preventDefault(); this.hasDragged = false; } }, true);
    },

    // ================= 智能兼容语音核心 =================
    loadVoices() {
        if (!this.ttsSupported) return;
        this.voiceList = window.speechSynthesis.getVoices();

        // 如果没有获取到任何语音，说明设备存在兼容性问题
        if (this.voiceList.length === 0) {
            console.warn("⚠️ 未检测到任何语音包，等待加载或设备不支持。");
            return;
        }

        const select = document.getElementById('voice-select');
        if (!select) return;

        select.innerHTML = '<option value="">默认智能匹配</option>';
        let hasZh = false;

        this.voiceList.forEach((voice, index) => {
            // 列出所有声线，中文排前面
            const isZh = voice.lang.includes('zh');
            const isEn = voice.lang.includes('en');
            if (isZh || isEn) {
                const option = document.createElement('option');
                option.value = index;
                option.innerText = `${voice.name} (${voice.lang})`;
                if (isZh) option.style.color = '#d63031';
                select.appendChild(option);
                if (isZh) hasZh = true;
            }
        });

        // 如果系统里连一个中文语音都没有，自动选用默认声音（防止用户选了英文导致中文乱读）
        if (!hasZh) {
            console.warn("⚠️ 系统未安装中文语音包，将使用默认引擎合成。");
            const voiceSelectParent = select.parentElement;
            if (voiceSelectParent) voiceSelectParent.style.display = 'none';
        }

        // ===== 恢复上次选择的声线 =====
        if (!this._userPicked) {                         // 用户这次没手动改过，才还原
            let saved = '';
            try { saved = localStorage.getItem('takuVoice') || ''; } catch (e) {}
            if (saved) {
                const idx = this.voiceList.findIndex(v => v.name === saved || v.voiceURI === saved);
                if (idx >= 0) {
                    select.value = String(idx);          // 下拉框跟着选中
                    this.selectedVoice = this.voiceList[idx];
                }
            }
        }
    },

    applyVoiceSettings() {
        if (!this.ttsSupported) return;
        const rateSlider = document.getElementById('voice-rate');
        const pitchSlider = document.getElementById('voice-pitch');
        const select = document.getElementById('voice-select');
        if(rateSlider) this.voiceRate = parseFloat(rateSlider.value);
        if(pitchSlider) this.voicePitch = parseFloat(pitchSlider.value);
        if (select && select.value !== "") {
            this.selectedVoice = this.voiceList[select.value];
            this._userPicked = true;                     // 记一笔：用户手动选过了
            try {
                // setItem 只有两个参数；键名必须和上面读取时的 'takuVoice' 完全一致（大小写敏感）
                localStorage.setItem('takuVoice', this.selectedVoice.name || this.selectedVoice.voiceURI);
            } catch (e) {}
        } else {
            this.selectedVoice = null;                   // 选"默认智能匹配"= 清掉记忆，回到内置默认声线
            this._userPicked = true;
            try { localStorage.removeItem('takuVoice'); } catch (e) {}
        }
    },

    testVoice() {
        this.playVoice("你好，我是数据流机器人塔库！Hello!");
    },

    playVoice(text) {
        if (this.isMuted || !this.ttsSupported) return;
        window.speechSynthesis.resume();
        window.speechSynthesis.cancel();

        setTimeout(() => {
            if (this.isMuted) return;
            const utterance = new SpeechSynthesisUtterance(text);

            // 塔库开口时把背景音乐压低一点，说完立刻恢复（免得人声和音乐打架）
            const unduck = () => { if (window.bgmEngine) bgmEngine.duck(false); };
            const unduckTimer = setTimeout(unduck, Math.min(20000, 2000 + String(text).length * 320));
            utterance.onend = () => { clearTimeout(unduckTimer); unduck(); };

            // ==== 智能匹配逻辑 ====
            // 保险丝：selectedVoice 必须是真正的音色对象（typeof === 'object'）。
            // 万一被写成了 true / 字符串之类，这里退回自动匹配，而不是让 utterance.voice 赋值抛异常
            // —— 那种异常发生在 setTimeout 里，会被浏览器吞掉，表现就是"塔库突然不说话了"。
            const picked = (this.selectedVoice && typeof this.selectedVoice === 'object') ? this.selectedVoice : null;
            if (this.selectedVoice && !picked) {
                console.warn('[塔库] selectedVoice 不是有效的音色对象，已回退到默认声线：', this.selectedVoice);
            }
            if (picked) {
                // 用户手动选择了，尊重用户
                utterance.voice = picked;
                utterance.lang = picked.lang;
            } else {
                // 用户没选，引擎自动寻找最合适的中文语音
                utterance.lang = 'zh-TW';
                // 优先找本地中文，其次找云端中文
                const TAKU_VOICE = 'HsiaoChen';
                const bestZh = this.voiceList.find(v => v.name.includes(TAKU_VOICE)) ||
                               this.voiceList.find(v => v.lang.includes('zh-TW')) ||
                               this.voiceList.find(v => v.lang.includes('zh'));
                if (bestZh) {
                    utterance.voice = bestZh;
                    utterance.lang = bestZh.lang;   // ← 注意大小写：bestZh（写成 bestZH 会抛 ReferenceError，塔库直接哑掉）
                } else {
                    utterance.lang = 'zh-TW';       // 一个中文音色都没有时的兜底
                }
            }

            utterance.rate = this.voiceRate;
            utterance.pitch = this.voicePitch;

            utterance.onerror = (e) => {
                clearTimeout(unduckTimer); unduck();
                if (e.error === 'not-allowed') this.isAudioUnlocked = false;
                // 如果因为找不到语音报错，静默降级为纯文字
                if (e.error === 'language-unavailable' || e.error === 'voice-unavailable') {
                    console.warn("⚠️ 当前设备不支持该语言，降级为纯文字模式。");
                    this.ttsSupported = false;
                    if (this.muteBtn) this.muteBtn.style.display = 'none';
                }
            };
            if (window.bgmEngine) bgmEngine.duck(true);
            window.speechSynthesis.speak(utterance);
        }, 100);
    },
    // ================= 智能兼容语音核心结束 =================

    toggleSettings() {
        const panel = this.settingsPanel;
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    },

    handleBGMUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        if (window.bgmEngine && bgmEngine.useCustomFile(file)) {
            this.playVoice("背景音乐已更换！");
            return;
        }
        // 兜底：浏览器不支持 Web Audio 时，还是老办法直接塞给 <audio>
        const url = URL.createObjectURL(file);
        this.bgmAudio.src = url;
        this.bgmAudio.volume = parseFloat(document.getElementById('bgm-volume').value);
        this.bgmAudio.play().catch(e => {});
    },

    // 音量统一交给 bgmEngine：内置合成曲目和上传的 MP3 共用同一根音量条
    changeBGMVolume() {
        const slider = document.getElementById('bgm-volume');
        if (slider && window.bgmEngine) bgmEngine.setVolume(slider.value);
    },

    // 这个按钮只管塔库的语音；背景音乐归右上角的「🎵 音乐」按钮管
    toggleMute() {
        this.isMuted = !this.isMuted;
        if (this.isMuted) {
            if (this.muteBtn) this.muteBtn.innerText = '🔇';
            if (this.ttsSupported) window.speechSynthesis.cancel();
        } else {
            if (this.muteBtn) this.muteBtn.innerText = '🔊';
            this.playVoice("语音已开启，塔库随时待命！");
        }
        if (window.bgmEngine) bgmEngine.duck(false);
    },

    speak(text, duration = 0) {
        this.dialogElement.innerText = text;
        this.dialogBox.style.transform = 'scale(1.05)';
        setTimeout(() => { this.dialogBox.style.transform = 'scale(1)'; }, 200);
        this.playVoice(text);

        if (duration > 0) {
            clearTimeout(this.timer);
            this.timer = setTimeout(() => {
                this.dialogElement.innerText = textbookData.takuIdle;
            }, duration);
        }
    },

    setEmotion(emotion) {
        const taku = document.getElementById('taku');
        if (taku) taku.className = 'taku-robot ' + emotion;
    }
};