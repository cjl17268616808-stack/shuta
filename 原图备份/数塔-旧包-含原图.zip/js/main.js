document.addEventListener('DOMContentLoaded', async () => {
    bgmEngine.init();      // 背景音乐：默认曲目已选好，等第一次点击就自动响
    takuEngine.init();

    const data = await getTextbookData();

    if (!data || !data.chapters || data.chapters.length === 0) {
        console.error("❌ 教材数据为空！");
        const stage = document.getElementById('stage');
        if (stage) stage.innerHTML = '<div style="text-align:center; width:100%; color:#ff6b6b; font-size:1.5rem; padding:50px;">⚠️ 教材数据为空，请检查 data.js 或 Python 编译结果。</div>';
        takuEngine.speak("数据流中断了！", 3000);
        takuEngine.setEmotion("confused");
        return;
    }

    console.log("✅ 数据加载成功，章节数:", data.chapters.length);
    comicEngine.renderChapters(data);

    setTimeout(() => {
        takuEngine.speak(data.takuWelcome || "欢迎来到数塔！", 5000);
    }, 800);

    // 🧭 首次访问自动弹出新手引导；老用户可点右上角「❓ 怎么玩」重看
    setTimeout(() => {
        comicEngine.showGuide(false);
    }, 1200);

    // 绑定塔库点击事件
    const takuEl = document.getElementById('taku');
    if (takuEl) {
        takuEl.addEventListener('click', () => {
            takuEngine.speak("别戳我啦！我的数据流都被你戳乱了！", 2000);
            takuEngine.setEmotion("confused");
            setTimeout(() => takuEngine.setEmotion("normal"), 2000);
        });
    }

    // 绑定右上角返回大厅按钮
    const homeBtn = document.getElementById('global-home-btn');
    if (homeBtn) {
        homeBtn.onclick = () => comicEngine.goHome();
    }

    // 🎨 主视觉插画互动：鼠标视差 + 点击爆花
    const heroBanner = document.getElementById('hero-banner');
    const heroImg = document.getElementById('hero-img');
    if (heroBanner && heroImg) {
        heroBanner.addEventListener('mousemove', (e) => {
            const rect = heroBanner.getBoundingClientRect();
            const dx = (e.clientX - rect.left) / rect.width - 0.5;
            const dy = (e.clientY - rect.top) / rect.height - 0.5;
            heroImg.style.transform = `translate(${dx * -14}px, ${dy * -10}px) scale(1.05)`;
        });
        heroBanner.addEventListener('mouseleave', () => {
            heroImg.style.transform = '';
        });
        heroBanner.addEventListener('click', (e) => {
            comicEngine.spawnSpark(e.clientX, e.clientY);
            takuEngine.speak("那就是我们要攀登的数据高塔！", 2500);
        });
    }
});